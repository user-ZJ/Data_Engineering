# Purpose of This Directory

This directory contains the starter codes for 3 exercises for this lesson.

## Folder Structure
All exercises are in the starter sub-folder. Within the starter sub-folder there are 3 folders corresponding to the exercises.

+ Folder: Creating EMR Clusters
+ Folder: Submitting_spark_scripts  
+ Folder: Write_to_s3
