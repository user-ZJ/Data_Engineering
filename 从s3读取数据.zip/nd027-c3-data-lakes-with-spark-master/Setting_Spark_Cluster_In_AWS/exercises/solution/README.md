# Purpose of this Folder

This folder contains the solution to the __creating_emr_cluster__ exercise. 
