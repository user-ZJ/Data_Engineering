### This folder contains the demo code used in the Reading and Writing Data to AWS S3 page of the classroom.

Contents:
1. test_emr Jupyter notebook file
2. sparkify_log_small.json file
3. sparkify_log_small_2.json file
