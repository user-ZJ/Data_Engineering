# Introduction to Data Skewness

You will need to download the `parking_violation.csv` file from the classroom to do this exercise. 
