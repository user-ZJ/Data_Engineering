# Exercises for Lesson 4: Debugging and Optimization

This folder contains the exercises for Lesson 4: Debugging and Optimization.

1. Practice  Broadcast Joins
2. Repartition
3. Introduction to Data Skewness  
